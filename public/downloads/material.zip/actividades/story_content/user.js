function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6X2enoDgnTJ":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

